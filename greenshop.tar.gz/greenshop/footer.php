    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> greenShop - All rights reserved.</p>
    </footer>
</body>
</html>

