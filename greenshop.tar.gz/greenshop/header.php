<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>greenShop - Organic Fruits & Veggies</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1><a href="index.php">greenShop</a></h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="cart.php">Cart</a>
            <a href="register.php">Register</a>
	    <a href="login.php">Login</a>
	    <a href="profile.php">Profile</a>
        </nav>
    </header>
    <main>

